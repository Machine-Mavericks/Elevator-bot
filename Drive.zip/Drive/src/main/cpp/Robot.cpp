/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

#include <Drive/DifferentialDrive.h>
#include <IterativeRobot.h>
#include <Joystick.h>
#include <Spark.h>
#include <SpeedControllerGroup.h>
#include "ctre/Phoenix.h"
//#include <SmartDashboard.h>

Joystick *exampleStick;

/**
 * This is a demo program showing the use of the DifferentialDrive class.
 * Runs the motors with arcade steering.
 * 
 * note to self:
 * use GetRawAxis() and GetRawButton() for using buttons and joysticks
 * 
 */
class Robot : public frc::IterativeRobot {


  //frc::Spark elevator{0};
  WPI_TalonSRX m_elevator{1}; 
  frc::Spark m_frontLeft{2};
	frc::Spark m_rearLeft{1}; 
	frc::SpeedControllerGroup m_left{m_frontLeft, m_rearLeft};

	frc::Spark m_frontRight{4};
	frc::Spark m_rearRight{3}; 
	frc::SpeedControllerGroup m_right{m_frontRight, m_rearRight};

	frc::DifferentialDrive m_robotDrive{m_left, m_right};

  // frc::Spark m_leftMotor{0};
  // frc::Spark m_rightMotor{2};
  //frc::DifferentialDrive m_robotDrive{m_leftMotor, m_rightMotor};
  frc::Joystick controller{0};
  frc::Joystick m_stickRight{1};
  frc::Joystick m_stickLeft{2};
  //SmartDashboard.putNumber("Test", "This is a test");

 public:
  void TeleopPeriodic() {
    // Drive with arcade style
    //m_robotDrive.TankDrive(m_stickRight.GetRawAxis(1), m_stickLeft.GetY());
    m_robotDrive.TankDrive(m_stickRight.GetRawAxis(1)* -1, m_stickLeft.GetRawAxis(1)* -1); 
    m_elevator.Set(controller.GetRawAxis(5)* 0.6 - 0.1);
    //elevator.Set(controller.GetRawAxis(5)*-0.6 + 0.1);
    //elevator.Set(-1.0);
  }
};

START_ROBOT_CLASS(Robot)
